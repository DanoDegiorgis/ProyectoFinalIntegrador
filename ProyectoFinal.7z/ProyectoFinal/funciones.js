function enviar_wsp() {
    myWindow = window.open("https://api.whatsapp.com/send?phone=%2B541162684635&text=", "_blank", "width=500, height=500");
  }